<?php $__env->startSection('content'); ?>
    <h3 class="page-title">User actions</h3>
    <div class="panel panel-default">
        <div class="panel-heading">
            List
        </div>

        <div class="panel-body">
            <table class="table table-bordered table-striped <?php echo e(count($user_actions) > 0 ? 'datatable' : ''); ?> ">
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Action</th>
                        <th>Action model</th>
                        <th>Action id</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if(count($user_actions) > 0): ?>
                        <?php $__currentLoopData = $user_actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_action): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <tr data-entry-id="<?php echo e($user_action->id); ?>">
                                <td><?php echo e(isset($user_action->user->name) ? $user_action->user->name : ''); ?></td>
                                <td><?php echo e($user_action->action); ?></td>
                                <td><?php echo e($user_action->action_model); ?></td>
                                <td><?php echo e($user_action->action_id); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4">No entries in table</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>