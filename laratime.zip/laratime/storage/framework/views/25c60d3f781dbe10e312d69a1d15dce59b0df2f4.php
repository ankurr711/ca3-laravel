<?php $__env->startSection('content'); ?>
    <h3 class="page-title">Time entries</h3>

    <div class="panel panel-default">
        <div class="panel-heading">
            View
        </div>

        <div class="panel-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th>Project</th>
                            <td><?php echo e(isset($time_entry->project->name) ? $time_entry->project->name : ''); ?></td>
                        </tr>
                        <tr>
                            <th>Work type</th>
                            <td><?php echo e(isset($time_entry->work_type->name) ? $time_entry->work_type->name : ''); ?></td>
                        </tr>
                        <tr>
                            <th>Start time</th>
                            <td><?php echo e($time_entry->start_time); ?></td>
                        </tr>
                        <tr>
                            <th>End time</th>
                            <td><?php echo e($time_entry->end_time); ?></td>
                        </tr>
                    </table>
                </div>
            </div>

            <p>&nbsp;</p>

            <a href="<?php echo e(route('time_entries.index')); ?>" class="btn btn-default">Back to list</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>