<div class="page-header-inner">
    <div class="page-header-inner">
        <div class="navbar-header">
            <a href="<?php echo e(url('/')); ?>"
               class="navbar-brand">
                LaraTime
            </a>
        </div>
        <a href="javascript:;"
           class="menu-toggler responsive-toggler"
           data-toggle="collapse"
           data-target=".navbar-collapse">
        </a>

         <div class="top-menu">
            <ul class="nav navbar-nav pull-right">
                <li>
                    <a href="#" target="_blank">Powered by </a>
                </li>
            </ul>
        </div>
    </div>
</div>
